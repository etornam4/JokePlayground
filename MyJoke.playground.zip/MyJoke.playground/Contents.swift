var one = "I saw a man drop his scrable game on the street"
var two = "oh my did you help him?"
var three = "No I asked him what's the word on the street!"
